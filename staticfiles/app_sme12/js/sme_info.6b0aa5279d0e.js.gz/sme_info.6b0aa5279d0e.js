$(document).ready(function () {
      
    // $(".progress-bar").change(function () {
    //   var revenuecode = $("#id_f_revenue option:selected").data("code"); // get the selected  data-code from the HTML input
  
    //   if (revenuecode == "301") {
    //     $("div.revenue_etc").show();
    //     $("#id_f_revenue_etc").maskMoney({ precision: 0 });
    //     return true;
    //   } else {
    //     $("#id_f_revenue_etc").val("");
    //     $("div.revenue_etc").hide();
    //     return true;
    //   }
    // });

});
  